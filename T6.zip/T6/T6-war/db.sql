drop table  t_books;
drop table t_category;

create table t_category
(
    id   int primary key,
    name varchar(40)
);
insert into t_category(id, name)
values (1, 'Tin hoc'),
       (2, 'Van hoc');

create table t_books
(
    isbn   varchar(50) primary key,
    name   varchar(50),
    price  float,
    author varchar(50),
    cat_id int,
    foreign key(cat_id) references t_category(id)
);
insert into t_books(isbn, name, price, author, cat_id) values
    ('B00011', 'Lap trinh java', 200000, 'tien', 1),
    ('B00012', 'Lap trinh java nang cao', 220000, 'tung', 1),
    ('B00013', 'Lap trinh java nang cao o Viet Name', 220000, 'tung', 1),
    ('B00021', 'Van hoc Viet Nam', 120000, 'Anh', 2);
select * from t_category;
select * from t_books;