/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bean;

import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import javax.persistence.Query;
import model.Book;
import model.Category;

/**
 *
 * @author duynn5
 */
@Stateless
public class BookBean implements BookBeanLocal {

    private EntityManager em;

    @PostConstruct
    private void init() {
        em = Persistence.createEntityManagerFactory("JavaApplication13PU").createEntityManager();
    }

    @Override
    public List<Category> findAllCategories() {
        String hql = String.format("select a from %s a", Category.class.getName());
        return em.createQuery(hql)
                .getResultList();
    }

    @Override
    public List<Book> findBooksByCategoryAndName(Integer catId, String bookName) {
        // nếu catId = null thì: 
        //    + nếu bookName = null --> lấy all book
        //    + nếu bookName != null -> lấy all book LIKE name
        // nếu catId != null thì: 
        //    + nếu bookName = null --> lấy all book theo catId
        //    + nếu bookName != null -> lấy all book theo catId và LIKE name

        Query query;
        String hql = String.format("select a from %s a ", Book.class.getName());
        boolean bookNameKongCoValue = bookName == null || bookName.isEmpty();
        if (catId == null) {
            if (bookNameKongCoValue) {
                System.out.println("lay all book, khong filter gi ca");
                query = em.createQuery(hql);
            } else {
                hql += " where a.name like :name";
                query = em.createQuery(hql)
                        .setParameter("name", bookName)
                        .setParameter("name", "%" + bookName + "%");
            }
        } else {
            if (bookNameKongCoValue) {
                hql += " where a.category.id = :catId";
                query = em.createQuery(hql)
                        .setParameter("catId", catId);
            } else {
                hql += " where a.category.id = :catId and a.name like :name";
                query = em.createQuery(hql)
                        .setParameter("catId", catId)
                        .setParameter("name", "%" + bookName + "%");
            }
        }

        return query.getResultList();
    }
}
