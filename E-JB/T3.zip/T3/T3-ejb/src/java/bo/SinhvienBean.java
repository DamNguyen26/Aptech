/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bo;

import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.Persistence;
import model.SinhVien;

/**
 *
 * @author duynn5
 */
@Stateless
public class SinhvienBean implements SinhvienBeanLocal {

    private EntityManager em;

    @PostConstruct
    private void init() {
        em = Persistence.createEntityManagerFactory("My_PU").createEntityManager();
    }

    @Override
    public List<SinhVien> findAll() {
        String hql = String.format("select a from %s a", SinhVien.class.getName());
        return em.createQuery(hql)
                .getResultList();
    }

    @Override
    public SinhVien findByRollNo(String rollNo) {
        return em.find(SinhVien.class, rollNo);
    }

    @Override
    public void addNew(SinhVien sv) {
        //addnew/update/delte can phai co transaction
        em.getTransaction().begin();
        em.persist(sv);
        em.getTransaction().commit();
    }

    @Override
    public void update(SinhVien sv) {
        //addnew/update/delte can phai co transaction
        em.getTransaction().begin();
        em.merge(sv);
        em.getTransaction().commit();
    }

    @Override
    public void deleteByRollNo(String rollNo) {
        //addnew/update/delte can phai co transaction
        SinhVien sv = em.find(SinhVien.class, rollNo);
        
        em.getTransaction().begin();
        em.remove(sv);
        em.getTransaction().commit();
    }
}
