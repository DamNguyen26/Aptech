create table t_student(roll_no varchar(20) primary key , full_name varchar(50), class_name varchar(50), dob date);
insert into t_student(roll_no, full_name, class_name, dob) values
    ('S0011', 'Ho Van Cuong', 'C0909KV', '1999-12-12'),
    ('S0012', 'Ho Van Cuong 2', 'C0911KV', '1999-12-12'),
    ('S0013', 'Ho Van Cuong 3', 'C0912KV', '1999-12-12'),
    ('S0014', 'Ho Van Cuong 4', 'C0913KV', '1999-11-12');
select * from t_student;

